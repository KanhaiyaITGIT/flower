import React, { useState, useEffect, useRef } from "react";
import {
  ArrowRight,
  Heart,
  Leaf,
  Sparkles,
  Clock,
  Phone,
  MessageCircle,
  Star,
  Flower2,
  Quote,
  ShieldCheck,
  Truck,
  Award,
  Users,
} from "lucide-react";

// ─── Animated counter on scroll ───────────────────
const AnimatedCounter = ({ target, suffix = "", duration = 1600 }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const started = useRef(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const isDecimal = target % 1 !== 0;
          const steps = 55;
          const stepTime = duration / steps;
          let step = 0;
          const timer = setInterval(() => {
            step++;
            const p = step / steps;
            const eased = 1 - Math.pow(1 - p, 3);
            setCount(isDecimal ? parseFloat((eased * target).toFixed(1)) : Math.floor(eased * target));
            if (step >= steps) clearInterval(timer);
          }, stepTime);
        }
      },
      { threshold: 0.4 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);
  return <span ref={ref}>{count}{suffix}</span>;
};

// ─── Scroll reveal ────────────────────────────────
const useReveal = (threshold = 0.12) => {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return [ref, visible];
};

// ─── Data ─────────────────────────────────────────
const values = [
  { icon: Leaf,     title: "Farm Fresh, Always",     desc: "We forecast demand and source daily — so every stem arrives the same day it's cut. Zero day-old inventory, ever.", color: "#34d399", bg: "#f0fdf9" },
  { icon: Heart,    title: "Design-Led Thinking",    desc: "Flowers aren't filler. Every arrangement is intentional — colour, form, and occasion considered from the first stem.", color: "#e8667a", bg: "#fdf2f4" },
  { icon: Clock,    title: "Reliable to the Hour",   desc: "Same-day delivery, real-time updates, and a team that picks up the phone. Gifting should be joyful, not stressful.", color: "#c9a96e", bg: "#fdf8f0" },
  { icon: Sparkles, title: "Made to Order",          desc: "No warehouse blooms. Every bouquet and décor setup is handcrafted when you order — for you, not for a shelf.", color: "#a78bfa", bg: "#f5f3ff" },
];

const milestones = [
  { year: "2016", title: "Founded", desc: "Started with one van, one vendor, and one promise — flowers that feel personal. A small studio with a big vision.", color: "#e8667a" },
  { year: "2018", title: "Décor Division Launched", desc: "Wedding and event floristry added. Our first full mandap setup led to 40 bookings in the same month.", color: "#c9a96e" },
  { year: "2021", title: "Subscription Model", desc: "Weekly fresh flower subscriptions launched. Homes across the city started waking up to new blooms every Monday.", color: "#a78bfa" },
  { year: "2023", title: "Corporate Gifting", desc: "Bulk and branded floristry for offices, launches, and teams — bringing freshness to the boardroom.", color: "#34d399" },
  { year: "2026", title: "Design Studio", desc: "Full-service floral design studio opened — from concept mood boards to day-of execution for premium events.", color: "#c9a96e" },
];

const team = [
  { name: "anuj",  role: "Co-Founder & Creative Director", detail: "10+ years in floral design. Every arrangement carries her eye for colour and composition.", initials: "PT", accent: "#e8667a" },
  { name: "Amit",   role: "Co-Founder & Operations",        detail: "Built the logistics backbone that makes same-day delivery feel effortless.", initials: "AT", accent: "#c9a96e" },
  { name: "lorem",     role: "Head of Décor",                  detail: "Led 200+ wedding and event setups. She reads a space and sees what it wants to become.", initials: "RS", accent: "#a78bfa" },
  { name: "Kkkkk",     role: "Supply & Freshness Lead",        detail: "Former horticulturist. He's the reason every petal arrives at peak bloom.", initials: "KM", accent: "#34d399" },
];

const stats = [
  { value: 500,   suffix: "+",   label: "Events Decorated" },
  { value: 12000, suffix: "+",   label: "Bouquets Delivered" },
  { value: 4.9,   suffix: "★",  label: "Average Rating" },
  { value: 8,     suffix: " yrs", label: "Of Freshness" },
];

const testimonials = [
  { text: "The flowers arrived hours before the wedding and looked as though they'd just been picked. Every guest commented on them.", name: "Meera S.", occasion: "Wedding client", rating: 5 },
  { text: "I've tried four florists in two years. BMF is the only one that actually delivers what they show in the photos — every single time.", name: "Rohan K.", occasion: "Monthly subscriber", rating: 5 },
  { text: "Our office wanted something warm and thoughtful for Diwali gifting. They handled 80 arrangements without a single complaint.", name: "Priya M.", occasion: "Corporate client", rating: 5 },
];

const trustBadges = [
  { icon: Truck,       label: "Same-Day Delivery" },
  { icon: ShieldCheck, label: "Freshness Guarantee" },
  { icon: Award,       label: "500+ 5-Star Events" },
  { icon: Users,       label: "12,000+ Happy Customers" },
];

// ─── Component ────────────────────────────────────
const AboutUs = () => {
  const [heroRef, heroVisible]     = useReveal(0.05);
  const [storyRef, storyVisible]   = useReveal();
  const [valuesRef, valuesVisible] = useReveal();

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap');

        *, *::before, *::after { box-sizing: border-box; }
        .abp * { font-family: 'DM Sans', sans-serif; }
        .abp .dp { font-family: 'Cormorant Garamond', serif; }

        @keyframes floatPetal {
          0%,100% { transform: translateY(0) rotate(0deg); }
          33%     { transform: translateY(-14px) rotate(4deg); }
          66%     { transform: translateY(-6px) rotate(-3deg); }
        }
        @keyframes revealUp {
          from { opacity: 0; transform: translateY(32px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes goldShimmer {
          0%   { background-position: -200% center; }
          100% { background-position:  200% center; }
        }
        @keyframes pulseDot {
          0%,100% { transform: scale(1);   opacity: 1; }
          50%     { transform: scale(1.6); opacity: 0.6; }
        }
        @keyframes rotateSlow {
          from { transform: translate(-50%,-50%) rotate(0deg); }
          to   { transform: translate(-50%,-50%) rotate(360deg); }
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        .float-slow { animation: floatPetal 9s ease-in-out infinite; }
        .float-med  { animation: floatPetal 7s 1.5s ease-in-out infinite; }

        .ru  { animation: revealUp 0.8s cubic-bezier(0.16,1,0.3,1) both; }
        .ru1 { animation: revealUp 0.8s 0.10s cubic-bezier(0.16,1,0.3,1) both; }
        .ru2 { animation: revealUp 0.8s 0.22s cubic-bezier(0.16,1,0.3,1) both; }
        .ru3 { animation: revealUp 0.8s 0.36s cubic-bezier(0.16,1,0.3,1) both; }
        .ru4 { animation: revealUp 0.8s 0.50s cubic-bezier(0.16,1,0.3,1) both; }

        .gold-text {
          background: linear-gradient(90deg,#c9a96e,#f0d5a0,#c9a96e,#a07840,#c9a96e);
          background-size: 300% auto;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: goldShimmer 5s linear infinite;
        }

        /* ─ value card hover ─ */
        .val-card { transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.35s ease; }
        .val-card:hover { transform: translateY(-6px); box-shadow: 0 22px 52px rgba(0,0,0,0.09); }

        /* ─ team card hover ─ */
        .tm-card { transition: transform 0.3s ease; }
        .tm-card:hover { transform: translateY(-4px); }
        .tm-avatar { transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1); }
        .tm-card:hover .tm-avatar { transform: scale(1.07); }

        /* ─ primary cta ─ */
        .cta-pri {
          background: linear-gradient(135deg,#e8667a,#d4546a);
          transition: transform 0.25s, box-shadow 0.25s;
          display: inline-flex; align-items: center; gap: 8px;
          color:#fff; border-radius:100px; text-decoration:none;
          font-size:14px; font-weight:700; border:none; cursor:pointer;
        }
        .cta-pri:hover { transform: translateY(-2px); box-shadow: 0 14px 36px rgba(232,102,122,0.4); }

        /* ─ ghost cta ─ */
        .cta-ghost {
          display: inline-flex; align-items: center; gap: 8px;
          border-radius: 100px; text-decoration:none; font-weight:700;
          transition: transform 0.25s, background 0.25s;
        }
        .cta-ghost:hover { transform: translateY(-2px); }

        /* scrollbar-hide */
        .sh::-webkit-scrollbar { display:none; }
        .sh { -ms-overflow-style:none; scrollbar-width:none; }

        /* ════════════════════════════════
           RESPONSIVE BREAKPOINTS
        ════════════════════════════════ */

        /* Hero */
        .hero-inner { padding: 110px 24px 90px; }
        .hero-h1    { font-size: clamp(2.6rem, 7vw, 5rem); line-height: 1.04; }
        .hero-sub   { font-size: clamp(0.9rem, 2.5vw, 1.08rem); }

        /* Stats */
        .stats-wrap { display: grid; grid-template-columns: repeat(4,1fr); }
        @media (max-width: 600px) {
          .stats-wrap { grid-template-columns: repeat(2,1fr); }
          .stats-wrap > div:nth-child(2) { border-right: none !important; }
          .stats-wrap > div:nth-child(3) { border-right: 1px solid rgba(255,255,255,0.06) !important; }
          .stats-wrap > div:nth-child(1),
          .stats-wrap > div:nth-child(2) { border-bottom: 1px solid rgba(255,255,255,0.06); }
        }

        /* Story two-col */
        .story-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: start; }
        @media (max-width: 820px) { .story-grid { grid-template-columns: 1fr; gap: 36px; } }

        /* Story headline */
        .story-h2 { font-size: clamp(2rem, 5vw, 3.8rem); }

        /* Values 2×2 */
        .vals-grid { display: grid; grid-template-columns: repeat(2,1fr); gap: 20px; }
        @media (max-width: 640px) { .vals-grid { grid-template-columns: 1fr; } }

        /* Timeline */
        .tl-wrap { position: relative; padding-left: 44px; }
        .tl-line { position: absolute; left: 10px; top: 8px; bottom: 8px; width: 2px;
          background: linear-gradient(180deg,#e8667a,#c9a96e,#a78bfa,#34d399,#c9a96e); }
        @media (max-width: 500px) {
          .tl-wrap { padding-left: 32px; }
          .tl-dot  { left: -29px !important; }
        }

        /* Team */
        .team-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 20px; }
        @media (max-width: 900px) { .team-grid { grid-template-columns: repeat(2,1fr); } }
        @media (max-width: 420px) { .team-grid { grid-template-columns: 1fr; } }

        /* Mission/Vision */
        .mv-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        @media (max-width: 720px) { .mv-grid { grid-template-columns: 1fr; } }

        /* Trust badges */
        .trust-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 16px; }
        @media (max-width: 700px) { .trust-grid { grid-template-columns: repeat(2,1fr); } }

        /* Testimonials */
        .testi-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; }
        @media (max-width: 820px) { .testi-grid { grid-template-columns: 1fr 1fr; } }
        @media (max-width: 520px) { .testi-grid { grid-template-columns: 1fr; } }

        /* CTA buttons */
        .cta-row { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; }
        @media (max-width: 420px) {
          .cta-row { flex-direction: column; align-items: stretch; }
          .cta-row a, .cta-row button { justify-content: center; }
        }

        /* Hero CTA row */
        .hero-cta-row { display: flex; flex-wrap: wrap; gap: 12px; }
        @media (max-width: 400px) {
          .hero-cta-row { flex-direction: column; }
          .hero-cta-row a { justify-content: center; }
        }

        /* Section padding */
        .sp { padding: 80px 24px; }
        @media (max-width: 600px) { .sp { padding: 56px 16px; } }

        .inner { max-width: 1100px; margin: 0 auto; }
        .inner-md { max-width: 800px; margin: 0 auto; }
        .inner-sm { max-width: 680px; margin: 0 auto; }

        /* Values heading */
        .vals-h2 { font-size: clamp(1.8rem, 5vw, 3.2rem); }
        /* Team heading */
        .team-h2 { font-size: clamp(1.8rem, 5vw, 3.2rem); }
        /* Final CTA heading */
        .cta-h2  { font-size: clamp(2rem, 6vw, 3.5rem); }

        @media (prefers-reduced-motion: reduce) {
          .float-slow, .float-med, .gold-text, .ru, .ru1, .ru2, .ru3, .ru4 {
            animation: none !important;
          }
        }
      `}</style>

      <div className="abp">     
        <section style={{
          background: "linear-gradient(135deg,#0d0805 0%,#1a0f0a 40%,#120c08 100%)",
          position: "relative", overflow: "hidden",
          minHeight: "85vh", display: "flex", alignItems: "center"
        }}>
          {/* Gold left bar */}
          <div style={{
            position:"absolute",left:0,top:0,bottom:0,width:"3px",
            background:"linear-gradient(180deg,transparent,#c9a96e 30%,#f0d5a0 60%,#c9a96e 85%,transparent)"
          }} />

          {/* Floating petals */}
          <div className="float-slow" style={{ position:"absolute",top:"12%",right:"5%",opacity:0.13,pointerEvents:"none" }}>
            <svg width="100" height="100" viewBox="0 0 100 100">
              {[0,72,144,216,288].map(a=>(
                <ellipse key={a} cx="50" cy="25" rx="11" ry="22" fill="#c9a96e" transform={`rotate(${a} 50 50)`}/>
              ))}
              <circle cx="50" cy="50" r="8" fill="#f0d5a0"/>
            </svg>
          </div>
          <div className="float-med" style={{ position:"absolute",bottom:"18%",right:"20%",opacity:0.08,pointerEvents:"none" }}>
            <svg width="64" height="64" viewBox="0 0 100 100">
              {[0,60,120,180,240,300].map(a=>(
                <ellipse key={a} cx="50" cy="25" rx="10" ry="20" fill="#e8667a" transform={`rotate(${a} 50 50)`}/>
              ))}
            </svg>
          </div>
          {/* Radial glow */}
          <div style={{
            position:"absolute",top:"35%",left:"38%",width:"500px",height:"350px",
            borderRadius:"50%",pointerEvents:"none",
            background:"radial-gradient(ellipse,rgba(201,169,110,0.07) 0%,transparent 70%)"
          }}/>

          <div className="inner hero-inner" style={{ width:"100%" }}>
            <div ref={heroRef}>
              {/* Eyebrow */}
              <div className={heroVisible ? "ru" : ""} style={{
                display:"inline-flex",alignItems:"center",gap:"10px",marginBottom:"26px"
              }}>
                <div style={{
                  width:"6px",height:"6px",borderRadius:"50%",background:"#c9a96e",flexShrink:0,
                  animation:"pulseDot 2.4s ease-in-out infinite"
                }}/>
                <span style={{
                  color:"#c9a96e",fontSize:"11px",fontWeight:700,
                  letterSpacing:"0.2em",textTransform:"uppercase"
                }}>
                  Bring My Flowers · Est. 2016
                </span>
              </div>

              {/* Headline */}
              <h1 className={`dp hero-h1 ${heroVisible ? "ru1":""}`} style={{
                fontWeight:700, color:"#fff", maxWidth:"680px",
                marginBottom:"22px", letterSpacing:"-0.01em"
              }}>
                Flowers as
                <br/>
                <em className="dp gold-text" style={{fontStyle:"italic"}}>
                  intentional as you.
                </em>
              </h1>

              {/* Sub */}
              <p className={`hero-sub ${heroVisible ? "ru2":""}`} style={{
                color:"rgba(255,255,255,0.52)", lineHeight:1.75,
                maxWidth:"460px", marginBottom:"36px", fontWeight:300
              }}>
                We're a design-first floral studio. Built to make flowers feel less like an afterthought and more like the whole point.
              </p>

              {/* CTAs */}
              <div className={`hero-cta-row ${heroVisible ? "ru3":""}`}>
                <a href="/decor" className="cta-pri" style={{ padding:"14px 28px" }}>
                  <Sparkles size={14}/> See Our Work
                </a>
                <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer"
                  className="cta-ghost"
                  style={{
                    color:"#fff", padding:"13px 24px", fontSize:"14px",
                    border:"1px solid rgba(255,255,255,0.2)",
                    backdropFilter:"blur(8px)",
                    background:"rgba(255,255,255,0.06)"
                  }}
                  onMouseEnter={e=>{e.currentTarget.style.background="rgba(255,255,255,0.12)";e.currentTarget.style.borderColor="rgba(255,255,255,0.32)";}}
                  onMouseLeave={e=>{e.currentTarget.style.background="rgba(255,255,255,0.06)";e.currentTarget.style.borderColor="rgba(255,255,255,0.2)";}}
                >
                  <MessageCircle size={14}/> Chat with Us
                </a>
              </div>

              {/* Stars */}
              <div className={heroVisible ? "ru4":""} style={{
                display:"flex",alignItems:"center",gap:"10px",marginTop:"28px",flexWrap:"wrap"
              }}>
                <div style={{display:"flex",gap:"3px"}}>
                  {[...Array(5)].map((_,i)=><Star key={i} size={12} fill="#c9a96e" style={{color:"#c9a96e"}}/>)}
                </div>
                <span style={{color:"rgba(255,255,255,0.38)",fontSize:"12px"}}>4.9 · 800+ happy customers</span>
              </div>
            </div>
          </div>
        </section>

        {/* ── TRUST BADGE STRIP ────────────────────────── */}
        <section style={{ background:"#fff", borderBottom:"1px solid #f3f4f6" }}>
          <div className="inner" style={{ padding:"0 24px" }}>
            <div className="trust-grid" style={{ padding:"28px 0" }}>
              {trustBadges.map(({icon:Icon,label},i)=>(
                <div key={i} style={{
                  display:"flex",alignItems:"center",gap:"10px",
                  justifyContent:"center",
                  borderRight: i < trustBadges.length-1 ? "1px solid #f3f4f6" : "none",
                  padding:"0 12px"
                }}>
                  <div style={{
                    width:"36px",height:"36px",borderRadius:"50%",
                    background:"#fdf2f4",display:"flex",alignItems:"center",justifyContent:"center",
                    flexShrink:0
                  }}>
                    <Icon size={16} style={{color:"#e8667a"}}/>
                  </div>
                  <span style={{
                    fontSize:"13px",fontWeight:600,color:"#374151",
                    lineHeight:1.3
                  }}>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── STATS STRIP ──────────────────────────────── */}
        <section style={{
          background:"linear-gradient(135deg,#0f0b08,#1a1108,#0f0b08)",
          position:"relative",overflow:"hidden"
        }}>
          <div style={{ position:"absolute",top:0,left:0,right:0,height:"1px",
            background:"linear-gradient(90deg,transparent,rgba(201,169,110,0.5),rgba(232,102,122,0.35),rgba(201,169,110,0.5),transparent)"}}/>
          <div style={{ position:"absolute",bottom:0,left:0,right:0,height:"1px",
            background:"linear-gradient(90deg,transparent,rgba(201,169,110,0.25),transparent)"}}/>
          {/* center glow */}
          <div style={{
            position:"absolute",top:"50%",left:"50%",
            width:"500px",height:"180px",
            transform:"translate(-50%,-50%)",borderRadius:"50%",pointerEvents:"none",
            background:"radial-gradient(ellipse,rgba(201,169,110,0.1) 0%,transparent 70%)"
          }}/>

          <div className="inner stats-wrap" style={{ padding:"0 24px" }}>
            {stats.map(({value,suffix,label},i)=>(
              <div key={i} style={{
                padding:"clamp(1.6rem,4vw,2.4rem) 12px",
                textAlign:"center",
                borderRight: i<3 ? "1px solid rgba(255,255,255,0.06)" : "none"
              }}>
                <div className="dp" style={{
                  fontSize:"clamp(1.8rem,5vw,2.7rem)",fontWeight:700,lineHeight:1,marginBottom:"8px",
                  background:"linear-gradient(135deg,#f0d5a0 0%,#c9a96e 50%,#a07840 100%)",
                  WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text"
                }}>
                  <AnimatedCounter target={value} suffix={suffix}/>
                </div>
                <div style={{color:"rgba(255,255,255,0.38)",fontSize:"10px",fontWeight:700,letterSpacing:"0.16em",textTransform:"uppercase"}}>
                  {label}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── STORY ────────────────────────────────────── */}
        <section className="sp" style={{ background:"#faf7f2" }}>
          <div className="inner" ref={storyRef}>
            {/* Section label */}
            <div style={{display:"flex",alignItems:"center",gap:"14px",marginBottom:"52px"}}>
              <div style={{height:"1px",width:"36px",background:"#e8667a"}}/>
              <span style={{color:"#e8667a",fontSize:"11px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase"}}>
                Our Story
              </span>
            </div>

            <div className={`story-grid ${storyVisible?"":"opacity-0"}`}>
              {/* Left */}
              <div>
                <h2 className={`dp story-h2 ${storyVisible?"ru":""}`} style={{
                  fontWeight:700,color:"#1a0f0a",lineHeight:1.06,
                  marginBottom:"28px",letterSpacing:"-0.01em"
                }}>
                  We started because
                  <br/>
                  <em className="dp" style={{color:"#c9a96e",fontStyle:"italic"}}>
                    flowers deserved better.
                  </em>
                </h2>

                {/* Pull quote */}
                <div style={{borderLeft:"3px solid #e8667a",paddingLeft:"20px",marginBottom:"28px"}}>
                  <p style={{color:"#6b4c3b",fontSize:"1.02rem",lineHeight:1.7,fontStyle:"italic"}}>
                    "India's flower market wastes nearly 30% of its produce daily. We set out to fix that — and make something beautiful in the process."
                  </p>
                  <p style={{color:"#c9a96e",fontSize:"12px",fontWeight:700,marginTop:"10px",letterSpacing:"0.08em"}}>
                    — Pooja Tripathi, Co-Founder
                  </p>
                </div>

                {/* Ornament */}
                <div style={{display:"flex",gap:"6px",alignItems:"center"}}>
                  {["#e8667a","#c9a96e","#e8667a"].map((c,i)=>(
                    <svg key={i} width="18" height="18" viewBox="0 0 100 100" style={{opacity:0.75}}>
                      {[0,72,144,216,288].map(a=>(
                        <ellipse key={a} cx="50" cy="25" rx="10" ry="20" fill={c} transform={`rotate(${a} 50 50)`}/>
                      ))}
                      <circle cx="50" cy="50" r="6" fill={c}/>
                    </svg>
                  ))}
                </div>
              </div>

              {/* Right */}
              <div style={{paddingTop:"4px"}}>
                <p style={{color:"#7a5c4f",fontSize:"1rem",lineHeight:1.8,marginBottom:"18px"}}>
                  Bring My Flowers was started in 2016 by Pooja and Amit Tripathi. The idea was disarmingly simple: what if flowers actually arrived the day they were cut, arranged by someone who cared, and delivered like they mattered?
                </p>
                <p style={{color:"#7a5c4f",fontSize:"1rem",lineHeight:1.8,marginBottom:"18px"}}>
                  India's floriculture system is traditionally fragmented and waste-heavy. Most shops work on next-day inventory, not today's farm output. We built the opposite — a demand-first, design-first model that sources every morning and delivers every afternoon.
                </p>
                <p style={{color:"#7a5c4f",fontSize:"1rem",lineHeight:1.8}}>
                  What started as a delivery business became a design studio. Today we do everyday gifting, event décor, corporate arrangements, and wedding floristry — all under one roof, all with the same promise: fresh, intentional, on time.
                </p>

                <div style={{marginTop:"28px",display:"flex",flexWrap:"wrap",gap:"10px"}}>
                  {["Farm-to-door freshness","Design-led always","India's first farm-direct model"].map((tag,i)=>(
                    <span key={i} style={{
                      background:"#fff",border:"1px solid #e8d5c0",
                      color:"#9a6b4b",borderRadius:"100px",
                      padding:"6px 16px",fontSize:"12px",fontWeight:600
                    }}>✓ {tag}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── VALUES ───────────────────────────────────── */}
        <section className="sp" style={{ background:"#fff" }}>
          <div className="inner">
            <div style={{textAlign:"center",marginBottom:"52px"}}>
              <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:"14px",marginBottom:"14px"}}>
                <div style={{height:"1px",width:"28px",background:"#c9a96e"}}/>
                <span style={{color:"#c9a96e",fontSize:"11px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase"}}>
                  What We Stand For
                </span>
                <div style={{height:"1px",width:"28px",background:"#c9a96e"}}/>
              </div>
              <h2 className="dp vals-h2" style={{
                fontWeight:700,color:"#1a0f0a",lineHeight:1.1,marginBottom:"14px"
              }}>
                Four things we
                <em className="dp" style={{color:"#e8667a",fontStyle:"italic"}}> never compromise.</em>
              </h2>
              <p style={{color:"#9a7c6f",fontSize:"0.93rem",maxWidth:"380px",margin:"0 auto",lineHeight:1.7}}>
                These aren't marketing lines. They're the decisions we make before sunrise every morning.
              </p>
            </div>

            <div className="vals-grid" ref={valuesRef}>
              {values.map(({icon:Icon,title,desc,color,bg},i)=>(
                <div key={i} className="val-card" style={{
                  background:bg,borderRadius:"20px",padding:"clamp(24px,4vw,36px) clamp(20px,3vw,32px)",
                  border:`1px solid ${color}22`
                }}>
                  <div style={{
                    width:"48px",height:"48px",borderRadius:"14px",
                    background:"#fff",display:"flex",alignItems:"center",justifyContent:"center",
                    marginBottom:"18px",boxShadow:`0 4px 16px ${color}22`,flexShrink:0
                  }}>
                    <Icon size={22} style={{color}}/>
                  </div>
                  <h3 className="dp" style={{fontSize:"1.45rem",fontWeight:700,color:"#1a0f0a",marginBottom:"10px"}}>
                    {title}
                  </h3>
                  <p style={{color:"#8a6e63",fontSize:"0.9rem",lineHeight:1.75}}>{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── TESTIMONIALS ─────────────────────────────── */}
        <section className="sp" style={{ background:"#faf7f2" }}>
          <div className="inner">
            <div style={{textAlign:"center",marginBottom:"48px"}}>
              <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:"14px",marginBottom:"14px"}}>
                <div style={{height:"1px",width:"28px",background:"#e8667a"}}/>
                <span style={{color:"#e8667a",fontSize:"11px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase"}}>
                  What Clients Say
                </span>
                <div style={{height:"1px",width:"28px",background:"#e8667a"}}/>
              </div>
              <h2 className="dp" style={{
                fontSize:"clamp(1.8rem,5vw,3rem)",fontWeight:700,color:"#1a0f0a",lineHeight:1.1
              }}>
                Words from
                <em className="dp" style={{color:"#c9a96e",fontStyle:"italic"}}> real celebrations.</em>
              </h2>
            </div>

            <div className="testi-grid">
              {testimonials.map(({text,name,occasion,rating},i)=>(
                <div key={i} style={{
                  background:"#fff",borderRadius:"20px",
                  padding:"clamp(22px,3vw,32px)",
                  border:"1px solid #f0e8e0",
                  display:"flex",flexDirection:"column",gap:"14px"
                }}>
                  {/* Stars */}
                  <div style={{display:"flex",gap:"3px"}}>
                    {[...Array(rating)].map((_,j)=>(
                      <Star key={j} size={13} fill="#c9a96e" style={{color:"#c9a96e"}}/>
                    ))}
                  </div>
                  {/* Quote icon */}
                  <Quote size={22} style={{color:"#e8667a",opacity:0.4}}/>
                  <p style={{color:"#6b4c3b",fontSize:"0.92rem",lineHeight:1.75,flex:1,fontStyle:"italic"}}>
                    {text}
                  </p>
                  <div style={{borderTop:"1px solid #f3f4f6",paddingTop:"14px"}}>
                    <p style={{fontWeight:700,color:"#1a0f0a",fontSize:"14px"}}>{name}</p>
                    <p style={{color:"#c9a96e",fontSize:"11px",fontWeight:600,letterSpacing:"0.06em",textTransform:"uppercase"}}>
                      {occasion}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── TIMELINE ─────────────────────────────────── */}
        <section className="sp" style={{ background:"#fff" }}>
          <div className="inner-md">
            <div style={{textAlign:"center",marginBottom:"56px"}}>
              <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:"14px",marginBottom:"14px"}}>
                <div style={{height:"1px",width:"26px",background:"#e8667a"}}/>
                <span style={{color:"#e8667a",fontSize:"11px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase"}}>
                  Our Journey
                </span>
                <div style={{height:"1px",width:"26px",background:"#e8667a"}}/>
              </div>
              <h2 className="dp" style={{
                fontSize:"clamp(1.8rem,5vw,3rem)",fontWeight:700,color:"#1a0f0a",lineHeight:1.1
              }}>
                Rooted in craft,
                <br/>
                <em className="dp" style={{color:"#c9a96e",fontStyle:"italic"}}>growing every season.</em>
              </h2>
            </div>

            <div className="tl-wrap">
              <div className="tl-line"/>
              <div style={{display:"flex",flexDirection:"column",gap:"44px"}}>
                {milestones.map(({year,title,desc,color},i)=>(
                  <div key={i} style={{position:"relative"}}>
                    {/* Dot */}
                    <div className="tl-dot" style={{
                      position:"absolute",left:"-38px",top:"5px",
                      width:"14px",height:"14px",borderRadius:"50%",
                      background:color,border:"3px solid #fff",
                      boxShadow:`0 0 0 3px ${color}44`,
                      zIndex:2,flexShrink:0
                    }}/>
                    <span style={{
                      display:"inline-block",
                      background:color+"18",color:color,
                      fontSize:"11px",fontWeight:700,letterSpacing:"0.1em",
                      borderRadius:"100px",padding:"3px 12px",marginBottom:"8px"
                    }}>{year}</span>
                    <h3 className="dp" style={{fontSize:"1.3rem",fontWeight:700,color:"#1a0f0a",marginBottom:"6px"}}>
                      {title}
                    </h3>
                    <p style={{color:"#8a6e63",fontSize:"0.9rem",lineHeight:1.7,maxWidth:"500px"}}>
                      {desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ── TEAM ─────────────────────────────────────── */}
        <section className="sp" style={{ background:"#1a0f0a",position:"relative",overflow:"hidden" }}>
          {/* Ambient glows */}
          <div style={{position:"absolute",top:"-80px",right:"-80px",width:"360px",height:"360px",borderRadius:"50%",
            background:"radial-gradient(circle,rgba(201,169,110,0.09) 0%,transparent 70%)",pointerEvents:"none"}}/>
          <div style={{position:"absolute",bottom:"-60px",left:"-60px",width:"280px",height:"280px",borderRadius:"50%",
            background:"radial-gradient(circle,rgba(232,102,122,0.07) 0%,transparent 70%)",pointerEvents:"none"}}/>

          <div className="inner" style={{position:"relative"}}>
            <div style={{textAlign:"center",marginBottom:"52px"}}>
              <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:"14px",marginBottom:"14px"}}>
                <div style={{height:"1px",width:"26px",background:"#c9a96e",opacity:0.6}}/>
                <span style={{color:"#c9a96e",fontSize:"11px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase"}}>
                  The Minds Behind It
                </span>
                <div style={{height:"1px",width:"26px",background:"#c9a96e",opacity:0.6}}/>
              </div>
              <h2 className="dp team-h2" style={{fontWeight:700,color:"#fff",lineHeight:1.1,marginBottom:"14px"}}>
                People who care
                <br/>
                <em className="dp gold-text" style={{fontStyle:"italic"}}>about every petal.</em>
              </h2>
              <p style={{color:"rgba(255,255,255,0.42)",fontSize:"0.93rem",maxWidth:"340px",margin:"0 auto",lineHeight:1.7}}>
                A small team with deep craft. Each person owns their domain completely.
              </p>
            </div>

            <div className="team-grid">
              {team.map(({name,role,detail,initials,accent},i)=>(
                <div key={i} className="tm-card" style={{
                  background:"rgba(255,255,255,0.04)",
                  border:"1px solid rgba(255,255,255,0.08)",
                  borderRadius:"20px",padding:"clamp(22px,3vw,32px) clamp(18px,2vw,24px)",
                  textAlign:"center"
                }}>
                  <div className="tm-avatar" style={{
                    width:"68px",height:"68px",borderRadius:"50%",
                    background:`linear-gradient(135deg,${accent}33,${accent}66)`,
                    border:`2px solid ${accent}55`,
                    display:"flex",alignItems:"center",justifyContent:"center",
                    margin:"0 auto 14px",
                    fontSize:"1.25rem",fontWeight:700,color:accent,
                    fontFamily:"'Cormorant Garamond',serif"
                  }}>{initials}</div>
                  <h3 style={{color:"#fff",fontSize:"0.97rem",fontWeight:700,marginBottom:"4px"}}>{name}</h3>
                  <p style={{color:accent,fontSize:"10px",fontWeight:700,letterSpacing:"0.07em",
                    marginBottom:"12px",textTransform:"uppercase"}}>{role}</p>
                  <p style={{color:"rgba(255,255,255,0.42)",fontSize:"0.82rem",lineHeight:1.65}}>{detail}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── MISSION + VISION ─────────────────────────── */}
        <section className="sp" style={{ background:"#faf7f2" }}>
          <div className="inner">
            <div className="mv-grid">
              {/* Mission */}
              <div style={{
                background:"#1a0f0a",borderRadius:"24px",
                padding:"clamp(32px,5vw,48px) clamp(24px,4vw,40px)",
                position:"relative",overflow:"hidden"
              }}>
                <div style={{position:"absolute",top:"-24px",right:"-24px",opacity:0.07,pointerEvents:"none"}}>
                  <svg width="150" height="150" viewBox="0 0 100 100">
                    {[0,72,144,216,288].map(a=>(
                      <ellipse key={a} cx="50" cy="20" rx="12" ry="24" fill="#e8667a" transform={`rotate(${a} 50 50)`}/>
                    ))}
                  </svg>
                </div>
                <div style={{
                  display:"inline-block",background:"#e8667a22",color:"#e8667a",
                  fontSize:"10px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase",
                  borderRadius:"100px",padding:"4px 14px",marginBottom:"18px"
                }}>Our Mission</div>
                <h3 className="dp" style={{
                  fontSize:"clamp(1.6rem,4vw,2rem)",fontWeight:700,color:"#fff",
                  lineHeight:1.15,marginBottom:"16px"
                }}>
                  Freshness,
                  <em className="dp" style={{color:"#e8667a",fontStyle:"italic"}}> by design.</em>
                </h3>
                <p style={{color:"rgba(255,255,255,0.5)",fontSize:"0.93rem",lineHeight:1.75}}>
                  To deliver freshness, creativity, and meaning through every bouquet. We combine nature-inspired design with expert craftsmanship to bring purposeful flowers into modern lives — with reliability, design-led aesthetics, and service that feels personal.
                </p>
              </div>

              {/* Vision */}
              <div style={{
                background:"linear-gradient(135deg,#c9a96e,#a07840)",borderRadius:"24px",
                padding:"clamp(32px,5vw,48px) clamp(24px,4vw,40px)",
                position:"relative",overflow:"hidden"
              }}>
                <div style={{position:"absolute",top:"-24px",right:"-24px",opacity:0.15,pointerEvents:"none"}}>
                  <svg width="150" height="150" viewBox="0 0 100 100">
                    {[0,60,120,180,240,300].map(a=>(
                      <ellipse key={a} cx="50" cy="20" rx="10" ry="22" fill="#fff" transform={`rotate(${a} 50 50)`}/>
                    ))}
                  </svg>
                </div>
                <div style={{
                  display:"inline-block",background:"rgba(255,255,255,0.2)",color:"#fff",
                  fontSize:"10px",fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase",
                  borderRadius:"100px",padding:"4px 14px",marginBottom:"18px"
                }}>Our Vision</div>
                <h3 className="dp" style={{
                  fontSize:"clamp(1.6rem,4vw,2rem)",fontWeight:700,color:"#fff",
                  lineHeight:1.15,marginBottom:"16px"
                }}>
                  Flowers as
                  <em className="dp" style={{fontStyle:"italic",color:"rgba(255,255,255,0.85)"}}> everyday joy.</em>
                </h3>
                <p style={{color:"rgba(255,255,255,0.75)",fontSize:"0.93rem",lineHeight:1.75}}>
                  To make fresh flowers an everyday joy — not just a luxury for occasions. We aim to redefine how people gift, decorate, and celebrate through thoughtfully designed floral experiences that are easy to access, high in quality, and crafted with care.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ── FINAL CTA ────────────────────────────────── */}
        <section className="sp" style={{
          background:"linear-gradient(135deg,#1a0f0a 0%,#2a1810 100%)",
          position:"relative",overflow:"hidden"
        }}>
          {/* Large rotating petal bg */}
          <div style={{
            position:"absolute",top:"50%",left:"50%",opacity:0.04,pointerEvents:"none",
            animation:"rotateSlow 80s linear infinite",width:"480px",height:"480px"
          }}>
            <svg width="480" height="480" viewBox="0 0 100 100">
              {[0,30,60,90,120,150,180,210,240,270,300,330].map(a=>(
                <ellipse key={a} cx="50" cy="15" rx="8" ry="18" fill="#c9a96e" transform={`rotate(${a} 50 50)`}/>
              ))}
            </svg>
          </div>

          <div className="inner-sm" style={{textAlign:"center",position:"relative"}}>
            {/* Petal ornament */}
            <div style={{display:"flex",justifyContent:"center",gap:"6px",marginBottom:"24px"}}>
              {[...Array(3)].map((_,i)=>(
                <svg key={i} width="15" height="15" viewBox="0 0 100 100" style={{opacity:0.85}}>
                  {[0,72,144,216,288].map(a=>(
                    <ellipse key={a} cx="50" cy="24" rx="9" ry="20" fill="#c9a96e" transform={`rotate(${a} 50 50)`}/>
                  ))}
                  <circle cx="50" cy="50" r="7" fill="#f0d5a0"/>
                </svg>
              ))}
            </div>

            <h2 className="dp cta-h2" style={{
              fontWeight:700,color:"#fff",lineHeight:1.06,marginBottom:"18px"
            }}>
              Let's make something
              <br/>
              <em className="dp gold-text" style={{fontStyle:"italic"}}>
                beautiful together.
              </em>
            </h2>
            <p style={{
              color:"rgba(255,255,255,0.45)",fontSize:"clamp(0.9rem,2.5vw,1rem)",
              lineHeight:1.75,marginBottom:"36px",maxWidth:"420px",margin:"0 auto 36px"
            }}>
              Whether it's a single bouquet or a full wedding décor — we'd love to hear about your occasion.
            </p>

            <div className="cta-row">
              <a href="/decor" className="cta-pri" style={{padding:"15px 28px"}}>
                <Sparkles size={15}/> Plan Your Décor
              </a>
              <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer"
                className="cta-ghost"
                style={{
                  color:"#25d366",padding:"14px 26px",fontSize:"14px",
                  border:"1px solid rgba(37,211,102,0.3)",
                  background:"rgba(37,211,102,0.07)"
                }}
              >
                <MessageCircle size={15}/> WhatsApp Us
              </a>
              <a href="tel:+919999999999"
                className="cta-ghost"
                style={{
                  color:"rgba(255,255,255,0.6)",padding:"14px 24px",fontSize:"14px",
                  border:"1px solid rgba(255,255,255,0.12)"
                }}
              >
                <Phone size={14}/> Call Us
              </a>
            </div>

            <p style={{
              color:"rgba(255,255,255,0.2)",fontSize:"12px",
              marginTop:"24px"
            }}>
              We respond within 10 minutes · Available 9 AM – 9 PM daily
            </p>
          </div>
        </section>

      </div>
    </>
  );
};

export default AboutUs;