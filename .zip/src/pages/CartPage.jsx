import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  selectCartItems,
  selectCartTotal,
  selectCartCount,
  incrementQty,
  decrementQty,
  removeFromCart,
  clearCart,
} from "../redux/cartSlice";

export default function CartPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const items = useSelector(selectCartItems);
  const total = useSelector(selectCartTotal);
  const count = useSelector(selectCartCount);

  const delivery = total > 60 ? 0 : 5.99;
  const grandTotal = total + delivery;

  // Empty cart
  if (items.length === 0) {
    return (
      <div style={{
        minHeight: "80vh", display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        background: "#fafaf9", fontFamily: "'Inter', sans-serif",
        padding: "40px 20px", textAlign: "center",
      }}>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />
        <div style={{ fontSize: "72px", marginBottom: "20px" }}>🌸</div>
        <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 400, color: "#0D1F0F", margin: "0 0 12px" }}>
          Your cart is empty
        </h2>
        <p style={{ fontSize: "14px", color: "#9ca3af", lineHeight: 1.7, maxWidth: "320px", margin: "0 0 32px" }}>
          Explore our beautiful collection and add your favourite blooms.
        </p>
        <button
          onClick={() => navigate("/gallery")}
          style={{
            padding: "14px 36px", borderRadius: "999px", border: "none",
            background: "linear-gradient(to right, #fb7185, #e11d48)",
            color: "#fff", fontFamily: "'Inter', sans-serif",
            fontSize: "13px", fontWeight: 700, letterSpacing: "0.1em",
            textTransform: "uppercase", cursor: "pointer",
            boxShadow: "0 4px 20px rgba(244,63,94,0.3)",
          }}
        >
          Browse Gallery
        </button>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "80vh", background: "#fafaf9", fontFamily: "'Inter', sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />

      <style>{`
        .cart-row {
          display: flex; align-items: center; gap: 16px;
          padding: 18px 20px; background: #fff; border-radius: 14px;
          box-shadow: 0 2px 12px rgba(0,0,0,0.06);
          margin-bottom: 12px; transition: box-shadow 0.2s;
        }
        .cart-row:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .qty-btn {
          width: 32px; height: 32px; border-radius: 50%; border: 1.5px solid #e5e7eb;
          background: #fff; cursor: pointer; font-size: 16px;
          display: flex; align-items: center; justify-content: center;
          color: #374151; transition: all 0.15s; flex-shrink: 0;
        }
        .qty-btn:hover { border-color: #f43f5e; color: #f43f5e; background: #fff1f2; }
        .remove-btn {
          background: none; border: none; cursor: pointer;
          color: #d1d5db; font-size: 18px; padding: 4px; transition: color 0.15s;
          flex-shrink: 0;
        }
        .remove-btn:hover { color: #f43f5e; }
        .checkout-btn {
          width: 100%; padding: 15px; border-radius: 999px; border: none;
          background: linear-gradient(to right, #fb7185, #e11d48);
          color: #fff; font-family: 'Inter', sans-serif;
          font-size: 14px; font-weight: 700; letter-spacing: 0.1em;
          text-transform: uppercase; cursor: pointer;
          box-shadow: 0 6px 20px rgba(244,63,94,0.35);
          transition: transform 0.2s, box-shadow 0.2s; margin-bottom: 12px;
        }
        .checkout-btn:hover { transform: translateY(-1px); box-shadow: 0 10px 28px rgba(244,63,94,0.4); }
        .continue-btn {
          width: 100%; padding: 13px; border-radius: 999px;
          border: 1.5px solid #e5e7eb; background: #fff;
          color: #374151; font-family: 'Inter', sans-serif;
          font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s;
        }
        .continue-btn:hover { border-color: #f43f5e; color: #f43f5e; }
        @media (min-width: 768px) {
          .cart-layout { display: grid; grid-template-columns: 1fr 360px; gap: 24px; }
        }
      `}</style>

      {/* Page header */}
      <div style={{ background: "#0D1F0F", padding: "48px 24px 40px", textAlign: "center", marginBottom: "32px" }}>
        <p style={{ fontSize: "10px", letterSpacing: "0.3em", textTransform: "uppercase", color: "#C8A882", margin: "0 0 12px" }}>
          Your Selection
        </p>
        <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem, 5vw, 3rem)", fontWeight: 400, color: "#F7F0E8", margin: "0 0 8px" }}>
          Shopping Cart
        </h1>
        <p style={{ fontSize: "13px", color: "rgba(247,240,232,0.45)" }}>
          {count} item{count !== 1 ? "s" : ""} in your cart
        </p>
      </div>

      <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "0 20px 60px" }}>
        <div className="cart-layout">

          {/* Left: items */}
          <div>
            {/* Clear cart */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.2rem", fontWeight: 400, color: "#0D1F0F" }}>
                Your Blooms
              </h2>
              <button
                onClick={() => dispatch(clearCart())}
                style={{
                  background: "none", border: "none", cursor: "pointer",
                  fontSize: "12px", color: "#9ca3af", letterSpacing: "0.06em",
                  textTransform: "uppercase", transition: "color 0.15s",
                }}
                onMouseEnter={e => e.currentTarget.style.color = "#f43f5e"}
                onMouseLeave={e => e.currentTarget.style.color = "#9ca3af"}
              >
                Clear all
              </button>
            </div>

            {items.map((item) => (
              <div key={item.id} className="cart-row">
                {/* Image */}
                <div style={{ width: "72px", height: "72px", borderRadius: "10px", overflow: "hidden", flexShrink: 0, background: item.bg }}>
                  <img src={item.image} alt={item.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: "9px", letterSpacing: "0.18em", textTransform: "uppercase", color: item.color, marginBottom: "2px" }}>
                    {item.category}
                  </div>
                  <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1rem", fontWeight: 400, color: "#0D1F0F", margin: "0 0 4px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {item.name}
                  </h3>
                  <p style={{ fontSize: "11px", color: "#9ca3af", margin: 0 }}>
                    {item.season} · £{item.price} each
                  </p>
                </div>

                {/* Qty controls */}
                <div style={{ display: "flex", alignItems: "center", gap: "10px", flexShrink: 0 }}>
                  <button className="qty-btn" onClick={() => dispatch(decrementQty(item.id))}>−</button>
                  <span style={{ fontSize: "14px", fontWeight: 600, color: "#0D1F0F", minWidth: "20px", textAlign: "center" }}>
                    {item.quantity}
                  </span>
                  <button className="qty-btn" onClick={() => dispatch(incrementQty(item.id))}>+</button>
                </div>

                {/* Line total */}
                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", color: "#0D1F0F", flexShrink: 0, minWidth: "48px", textAlign: "right" }}>
                  £{(item.price * item.quantity).toFixed(2)}
                </div>

                {/* Remove */}
                <button className="remove-btn" onClick={() => dispatch(removeFromCart(item.id))} aria-label="Remove">✕</button>
              </div>
            ))}

            {/* Continue shopping */}
            <button className="continue-btn" onClick={() => navigate("/gallery")} style={{ marginTop: "8px" }}>
              ← Continue Shopping
            </button>
          </div>

          {/* Right: order summary */}
          <div>
            <div style={{
              background: "#fff", borderRadius: "16px",
              boxShadow: "0 4px 24px rgba(0,0,0,0.08)", overflow: "hidden",
              position: "sticky", top: "100px",
            }}>
              {/* Summary header */}
              <div style={{ background: "#0D1F0F", padding: "20px 24px" }}>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.15rem", fontWeight: 400, color: "#F7F0E8", margin: 0 }}>
                  Order Summary
                </h3>
              </div>

              <div style={{ padding: "20px 24px" }}>
                {/* Line items */}
                {items.map((item) => (
                  <div key={item.id} style={{ display: "flex", justifyContent: "space-between", marginBottom: "10px", fontSize: "13px" }}>
                    <span style={{ color: "#6b7280" }}>
                      {item.name} <span style={{ color: "#d1d5db" }}>×{item.quantity}</span>
                    </span>
                    <span style={{ color: "#0D1F0F", fontWeight: 500 }}>£{(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}

                <div style={{ height: "1px", background: "#f3f4f6", margin: "16px 0" }} />

                {/* Subtotal */}
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px", marginBottom: "8px" }}>
                  <span style={{ color: "#6b7280" }}>Subtotal</span>
                  <span style={{ color: "#0D1F0F", fontWeight: 500 }}>£{total.toFixed(2)}</span>
                </div>

                {/* Delivery */}
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px", marginBottom: "8px" }}>
                  <span style={{ color: "#6b7280" }}>Delivery</span>
                  <span style={{ color: delivery === 0 ? "#16a34a" : "#0D1F0F", fontWeight: 500 }}>
                    {delivery === 0 ? "FREE" : `£${delivery.toFixed(2)}`}
                  </span>
                </div>

                {/* Free delivery notice */}
                {delivery > 0 && (
                  <div style={{
                    background: "#fef9c3", border: "1px solid #fde047",
                    borderRadius: "8px", padding: "8px 12px",
                    fontSize: "11px", color: "#854d0e", marginBottom: "12px", lineHeight: 1.5,
                  }}>
                    Add £{(60 - total).toFixed(2)} more for FREE delivery 🚚
                  </div>
                )}

                {delivery === 0 && (
                  <div style={{
                    background: "#f0fdf4", border: "1px solid #bbf7d0",
                    borderRadius: "8px", padding: "8px 12px",
                    fontSize: "11px", color: "#166534", marginBottom: "12px",
                  }}>
                    ✓ You qualify for free delivery!
                  </div>
                )}

                <div style={{ height: "1px", background: "#f3f4f6", margin: "12px 0 16px" }} />

                {/* Grand total */}
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "20px" }}>
                  <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", color: "#0D1F0F" }}>Total</span>
                  <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.3rem", color: "#0D1F0F", fontWeight: 400 }}>
                    £{grandTotal.toFixed(2)}
                  </span>
                </div>

                <button className="checkout-btn">
                  Proceed to Checkout →
                </button>

                {/* Trust badges */}
                <div style={{ display: "flex", justifyContent: "center", gap: "16px", flexWrap: "wrap", marginTop: "12px" }}>
                  {["🔒 Secure", "🌿 Fresh", "🚚 Fast"].map((b) => (
                    <span key={b} style={{ fontSize: "10px", color: "#9ca3af" }}>{b}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
